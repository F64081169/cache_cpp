#include <iostream>
#include <fstream>
#include <math.h>
#include <string>
#include <cstdlib>
#include <climits>
using namespace std;

enum Associativity {dir_map = 0,four_set = 1,full = 2};
enum replace {FIFO = 0, LRU = 1, MINE = 2};

struct cache{
    int time = 0;
    int count = 0;
    bool valid = false;
    unsigned int tag = 0;
};

int choose_algo(struct cache *c,int associate,int replace,int tag,int index,int block_num){
    int min = INT_MAX;
    int ind = 0;
    int i = 0;
    int n_index=index*4;
    if(replace == 0)//FIFO
    {
        if (associate == 0)
            return index;
        if(associate==1){
            return index;
        }else return 4*index;
    }
    else if(replace == 1)//LRU
    {
        if(associate==0){
            while(i<block_num){
                if(c[i].valid==1 && c[i].tag!=tag)
                    if(min>c[i].time){
                        min = c[i].time;
                        ind = i;
                    }
                    i++;
            }
        }
        if(associate==1){
            while(i<4){
                if(c[n_index].valid==1 && c[n_index].tag!=tag)
                    if(min>c[n_index].time){
                        min = c[n_index].time;
                        ind = i;
                    }
                    i++;
            }

        }
        if(associate==2){
        while(i<block_num){
            if(c[i].valid==1 && c[i].tag!=tag)
                if (min>c[i].time){
                    min = c[i].time; 
                    ind = i;
            }
            i++; 
        }
        }
        return ind;
    }
    //your policy
    else{
        while(i<4){
            if(c[n_index+i].valid==1 && c[n_index+i].tag!=tag)
                if (min>c[n_index+i].count){
                    min = c[n_index+i].count; 
                    ind = n_index+i;
            } 
            i++;
        }
        
        return ind;

    }
    return index;

}

int get_indexb(int block,int ass){
    int index = 0;
    if(ass==0)index=log(block)/log(2);
    if(ass==1)index=log(block/4)/log(2);
    return index;

}

int b(int c,int b){
    return 1024*c/b;
}

int main(int argc, char* argv[]){
    fstream in_file;
    fstream out_file;
    in_file.open(argv[1],ios::in);
    out_file.open(argv[2],ios::out);
    int cache_size,block_size,associative,replace_algo,block_num;
    int offset,index_bits,tag_bits,index,time,rand,min,ind;
    unsigned int tag ,dat;
    bool vit = 0;
    in_file>>cache_size>>block_size>>associative>>replace_algo;
    block_num = b(cache_size,block_size);
    offset = block_size;
    cache c[block_num];
    for(int i = 0;i<block_num;i++){
        c[i].count=0;
        c[i].tag=0;
        c[i].time=0;
        c[i].valid=false;
    }
    in_file>>hex;
    switch (associative)
    {
    case Associativity::dir_map:
        index_bits = get_indexb(block_num,associative);
        tag_bits = 32 - index_bits - int(log(offset)/log(2));
        while (in_file>>dat)
        {
            index = (dat << tag_bits) >> (tag_bits + int(log(offset)/log(2)));
			tag = dat >> (index_bits + int(log(offset)/log(2)));
            if(!c[index].valid){
                c[index].valid = true;
                c[index].tag = tag;
                vit = 0;
                out_file<<-1<<endl;              
                }else{
                if(c[index].tag != tag){
                   vit = 1;
                }
                else{
                    vit = 0;
                    out_file<<-1<<endl;
                }
                if(vit){
                    ind = choose_algo(c,associative,replace_algo,tag,index,block_num);
                    out_file << c[ind].tag << endl;
                    c[ind].tag = tag;
                }
            }
        }
        break;
    case Associativity::four_set:
        index_bits = get_indexb(block_num,associative);
        tag_bits = 32  - index_bits - int(log(offset)/log(2));
        while (in_file>>dat)
        {
            index = (dat<<tag_bits)>>(tag_bits+int(log(offset)/log(2)));
            int n_index = index*4;
            int i = 0;
			tag = dat >>  (index_bits + int(log(offset)/log(2)));
            while(i<4){
                if(!c[n_index+i].valid){
                    c[n_index+i].valid = true;
                    c[n_index+i].tag = tag;
                    c[n_index+i].count++;
                    vit = 0;
                    out_file<<-1<<endl;
                    break;
                }else{
                    if(c[n_index+i].tag == tag){
                        vit = 0;
                        out_file<<-1<<endl;
                        c[n_index+1].count++;
                        break;
                    }
                else{
                    vit = 1;                       
                    }
                }
                i++;
            }
            if(vit){
            ind = choose_algo(c,associative,replace_algo,tag,index,block_num);
            out_file<<c[ind].tag<<endl;
            c[ind].tag = tag; 
            c[ind].count++;
            }           
        }
        break;
    case Associativity::full:
        tag_bits = 32 - int(log(offset)/log(2));
        time = 0;
        while (in_file>>dat)
        {
            tag = dat >> int(log(offset)/log(2));
            time ++;
            int i = 0;
            while(i<block_num){
            if(!c[i].valid){
                c[i].valid = true;
                c[i].tag = tag;
                c[i].time =time ;
                vit = 0;
                out_file<<-1<<endl;
                break;
            }else{
                if(c[i].tag == tag){
                    c[i].time = time;
                    vit = 0;
                    out_file<<-1<<endl;
                    break;
                }
                else{
                     vit = 1;        
                }
            }
            i++;
            }           
            if(vit){
                ind = choose_algo(c,associative,replace_algo,tag,index,block_num);
                out_file<<c[ind].tag<<endl;
                c[ind].time = time;
                c[ind].tag = tag;
            }
        }
        break;
    default:
        break;
    }
}

